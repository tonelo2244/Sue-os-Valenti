const express = require("express");
const app= express();
const path = require("path");
const PORT = 3000;

app.set("view engine", "ejs");

app.use(express.static(path.join(__dirname, "public")));

app.get("/form", (req, res) => {
  res.render("form", {
    nombre: "",
    edad: "",
    ciudad: "",
    email: "",
    intereses: []
  })
});

app.listen(PORT, () => {
    console.log (`servidor escuchando en : ${PORT}`)
})
