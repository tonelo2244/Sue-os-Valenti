const cookieParser = require("cookie-parser");
const session = require("express-session");
const express = require("express");
const path = require("path");
const fs = require("fs/promises");

const app = express();
const port = 3000;

// guardamos la ruta donde se almacenan los usuarios en un archivo JSON
const USERS_FILE = path.join(__dirname, "data", "usuarios.json");

async function leerUsuarios() {
  try {
    //lee el archivo usuarios.json como texto.
    const raw = await fs.readFile(USERS_FILE, "utf-8");

    //convierte el texto json en un array de objetos javascript y lo devuelve.
    return JSON.parse(raw);
  } catch (err) {
    if (err.code === "ENOENT") {

      // crea la carpeta Data si no existe 
      await fs.mkdir(path.join(__dirname, "data"), { recursive: true });
      await fs.writeFile(USERS_FILE, "[]", "utf-8");
      return [];
    }
    throw err;
  }
}

async function guardarUsuarios(usuarios) {
  await fs.writeFile(USERS_FILE, JSON.stringify(usuarios, null, 2), "utf-8");
}

// Middlewares => permiten leer formularios, cookies, compartir datos con las vistas 
// y gestionar sesiones de usuario
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

app.use((req, res, next) => {
  res.locals.tema = req.cookies.tema || "claro";
  next();
});

app.use(
  session({
    secret: "sueno-valenti-secreto",
    resave: false,
    saveUninitialized: false,
  })
);

// EJS
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Estáticos
app.use(express.static(path.join(__dirname, "public")));

// cera una sesion cuando el usuario hace login
function requireLogin(req, res, next) {
  if (!req.session.usuario) return res.redirect("/login");
  next();
}

// Validador custom registro => comprueba los datos del formulario, detecta errores 
// y devuelve todo listo para guardar 
function validarRegistro(body) {
  const errors = {};

  const nombre = (body.nombre || "").trim();

  // Quita espacios y pasa a minúsculas
  const email = (body.email || "").trim().toLowerCase();
  const edad = Number(body.edad);
  const ciudad = (body.ciudad || "").trim();
  const intereses = [].concat(body.intereses || []);

  // Validaciones
  if (!nombre) errors.nombre = "Nombre obligatorio";
  else if (nombre.length < 2) errors.nombre = "Nombre muy corto";

// Email obligatorio con una validación básica
  if (!email || !email.includes("@")) errors.email = "Email no válido";

  if (!edad || edad < 1 || edad > 120) errors.edad = "Edad inválida";

  if (ciudad && ciudad.length < 2) errors.ciudad = "Ciudad muy corta";

  if (intereses.length > 5) errors.intereses = "Máximo 5 intereses";

  // resultado final => devuelve errores y valores limpios
  return { errors, values: { nombre, email, edad, ciudad, intereses } };
}

// apartado 3 Manejo de sesiones y carrito 

const SERVICIOS = [
  { id: "masaje", nombre: "Masaje terapéutico con final feliz", precio: 35 },
  { id: "termales", nombre: "Baño en aguas termales", precio: 25 },
  { id: "aromaterapia", nombre: "Aromaterapia guiada", precio: 20 },
  { id: "meditacion", nombre: "Meditación grupal", precio: 15 },
];

function getCarrito(req) {
  return req.session.carrito || {};
}

function setCarrito(req, carrito) {
  req.session.carrito = carrito;
}

function carritoDetallado(req) {
  const carrito = getCarrito(req);
  let total = 0;

  const items = Object.keys(carrito).map(id => {
    const servicio = SERVICIOS.find(s => s.id === id);
    const qty = carrito[id];
    const subtotal = servicio.precio * qty;
    total += subtotal;

    return { ...servicio, qty, subtotal };
  });

  return { items, total };
}


// Rutas 

// Home
app.get("/", (req, res) => {
  res.render("index");
});

// Registro (GET) => muestra el formulario vacío
app.get("/registro", (req, res) => {
  res.render("registro", { values: {}, errors: {} });
});

// Registro => validamos y guardamos el usuario
app.post("/registro", async (req, res) => {
  const { errors, values } = validarRegistro(req.body);
  if (Object.keys(errors).length) {
    return res.render("registro", { values: req.body, errors });
  }

  const usuarios = await leerUsuarios();

  // evitamos  emails duplicados
  const existe = usuarios.some((u) => (u.email || "").toLowerCase() === values.email);
  if (existe) {
    return res.render("registro", { values: req.body, errors: { email: "Ese email ya existe" } });
  }

  usuarios.push(values);
  await guardarUsuarios(usuarios);

  req.session.usuario = values;
  res.redirect("/perfil");
});

// Login (GET)
app.get("/login", (req, res) => {
  res.render("login", { error: "" });
});

// Login (POST)
app.post("/login", async (req, res) => {
  const email = (req.body.email || "").trim().toLowerCase();
  if (!email) return res.render("login", { error: "Email obligatorio" });

  const usuarios = await leerUsuarios();
  const usuario = usuarios.find((u) => (u.email || "").toLowerCase() === email);

  if (!usuario) return res.render("login", { error: "Usuario no encontrado" });

  req.session.usuario = usuario;
  res.redirect("/perfil");
});

// Pefil
app.get("/perfil", requireLogin, (req, res) => {
  res.render("perfil", { usuario: req.session.usuario });
});

// Logout
app.post("/logout", (req, res) => {
  req.session.destroy(() => {
    res.redirect("/login");
  });
});

// Preferencias (req, res) => {
 // PREFERENCIAS
app.get("/preferencias", (req, res) => {
  const tema = req.query.tema;

  if (tema === "claro" || tema === "oscuro") {
    res.cookie("tema", tema, { maxAge: 1000 * 60 * 60 * 24 * 30 });
    return res.redirect("/preferencias");
  }

  res.render("preferencias");
});


// Sesiones 
app.get("/sesiones", requireLogin, (req, res) => {
  const carrito = carritoDetallado(req);
  res.render("sesiones", { servicios: SERVICIOS, carrito });
});

//Carrito: el carrito sirve para guardar las sesiones que el usuario va eligiendo. 
// Cada vez que se pulsa en “añadir”, la sesión se guarda en el carrito 
// y se pueden sumar varias. Desde la misma página se pueden quitar sesiones
//  o vaciar el carrito entero. 
// El precio total se calcula sumando todas las sesiones del carrito
//  y el carrito se mantiene mientras el usuario tenga la sesión iniciada.

// Añadir servicios al carrito
app.post("/carrito/add", requireLogin, (req, res) => {
  const id = req.body.id;
  const carrito = req.session.carrito || {};

  carrito[id] = (carrito[id] || 0) + 1;
  req.session.carrito = carrito;

  res.redirect("/sesiones");
});

// Eliminar servicios al carrito 
app.post("/carrito/remove", requireLogin, (req, res) => {
  const id = req.body.id;
  const carrito = req.session.carrito || {};

  if (carrito[id] > 1) carrito[id]--;
  else delete carrito[id];

  req.session.carrito = carrito;
  res.redirect("/sesiones");
});

// Vaciar carrito
app.post("/carrito/vaciar", requireLogin, (req, res) => {
  req.session.carrito = {};
  res.redirect("/sesiones");
});



// Servidor 
app.listen(port, () => {
  console.log(`Servidor escuchando en http://localhost:${port}`);
});
